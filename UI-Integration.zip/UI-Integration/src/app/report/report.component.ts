import { Component, OnInit } from '@angular/core';
import { ReportService } from './report.service';
 import { saveAs as importedSaveAs } from 'file-saver';


@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
public reportList:any=[];
  constructor(private reportService:ReportService) { }
  public emailId:string='';
  ngOnInit() {
    this.reportService.getFetchReportDtls().subscribe(data=>{
console.log('reportData',data);
this.reportList=data; 
console.log('list',this.reportList);
    })
  }
  public downloadReportTemplate(){

     this.reportService.downloadReport().subscribe(data => {
       const header = data.headers._headers.get('content-disposition')[0];
       const blob = new Blob([data._body], {
         type: 'application/excel'
       });
       importedSaveAs(blob, header.substr(header.indexOf('=') + 1));
       console.log('Value',data);
     });
  }
  public sendReportExcelEmail(){
    let requestBody={
        "emailId":this.emailId
        }
        console.log('req',requestBody);
  this.reportService.sendReportEmail(requestBody).subscribe(data=>{
    console.log('EmailId',data);
    if(data.message=="Mail has been sent successfully"){
     alert("Mail has been sent successfully");
    }
    else {
  alert("Mail has not been sent")
     }
    this.emailId='';
  })
  
}


}

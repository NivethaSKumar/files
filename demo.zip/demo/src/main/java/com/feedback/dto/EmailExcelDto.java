package com.feedback.dto;

public class EmailExcelDto {
 private String emailId;

public String getEmailId() {
	return emailId;
}

public void setEmailId(String emailId) {
	this.emailId = emailId;
}
 
 
}

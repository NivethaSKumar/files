import { AppPage } from './app.po';
import { browser, by,logging } from 'protractor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  // it('should display welcome message', () => {
  //   page.navigateTo();
  //   expect(page.getTitleText()).toEqual('feedbackManagementSystem app is running!');
  // });

  // afterEach(async () => {
  //   // Assert that there are no errors emitted from the browser
  //   const logs = await browser.manage().logs().get(logging.Type.BROWSER);
  //   expect(logs).not.toContain(jasmine.objectContaining({
  //     level: logging.Level.SEVERE,
  //   } as logging.Entry));
  // });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('FeedbackManagementSystem');
  });

  it('should be able to login user', () => {
    browser.element(by.name('EmailAddress')).sendKeys('nivetha@gmail.com');
    browser.driver.sleep(500);
    browser.element(by.name('txtPassword')).sendKeys('nivetha01');
    browser.driver.sleep(500);
    browser.element(by.id('btnSubmit')).click();
    expect(browser.getCurrentUrl()).toContain('/');
    browser.driver.sleep(1000);
  });

  it('should be able to login user with Valid Credentials', () => {
    browser.element(by.id('EmailAddress')).sendKeys('nivetha@gmail.com');
    browser.driver.sleep(500);
    browser.element(by.id('txtPassword')).sendKeys('nivetha01');
    browser.driver.sleep(500);
    browser.element(by.id('btnSubmit')).click();
    expect(browser.getCurrentUrl()).toContain('/');
    browser.driver.sleep(1000);
  });

  it('should be able to view feedbackMgmtSystem dashboard', () => {
    browser.driver.sleep(1000);
    browser.element(by.className('glyphicon glyphicon-th-large')).click();
    browser.driver.sleep(2000);
    expect(browser.getCurrentUrl()).toContain('/dashboard');
  });

  it('should be able to view feedbackMgmtSystem event page', () => {
       browser.element(by.name('EmailAddress')).sendKeys('nivethassk@gmail.com');
       browser.driver.sleep(500);
       browser.element(by.buttonText('Send Email')).click();
      // browser.element(by.css("button[id='emailBtn']")).click();
       expect(browser.getCurrentUrl()).toContain('/event');
       browser.driver.sleep(1000);
     });
  it('should be able to view feedbackMgmtSystem event page', () => {
    browser.driver.sleep(1000);
    browser.element(by.className('glyphicon glyphicon-list-alt')).click();
    browser.driver.sleep(2000);
    expect(browser.getCurrentUrl()).toContain('/dashboard');
  });

  it('should be able to view feedbackMgmtSystem report page', () => {
    browser.driver.sleep(1000);
    browser.element(by.className('glyphicon glyphicon-download-alt')).click();
    browser.driver.sleep(2000);
    expect(browser.getCurrentUrl()).toContain('/dashboard');
  });


});

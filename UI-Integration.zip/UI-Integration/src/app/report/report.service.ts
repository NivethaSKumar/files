import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ReportService {

  constructor(private http:HttpClient) { }

  public getFetchReportDtls():Observable<any>{
   const reportUrl='http://localhost:8120/feedback-mgmt/fetch-report'
     //return this.http.get('./assets/report.json');
    return this.http.get(reportUrl);

  }

  public loginDtls(obj):Observable<any>{
    const reportUrl='http://localhost:8120/feedback-mgmt/login-credentials'
    return this.http.post(reportUrl,obj);
  }
  public getEventDtls():Observable<any>{
    const eventDtls='http://localhost:8120/feedback-mgmt/fetch-event-dtls'
   // return this.http.get('./assets/event.json')
    return this.http.get(eventDtls);
  }
  public downloadReport():Observable<any>{
    const reportDownloadUrl='http://localhost:8120/feedback-mgmt/report-excel'
    return this.http.get(reportDownloadUrl);

  }

  public sendReportEmail(obj):Observable<any>{
    const reportEmailUrl='http://localhost:8120/feedback-mgmt/export-report'
    return this.http.post(reportEmailUrl,obj)
  }

  public saveFeedback(obj):Observable<any>{
    const feedback='http://localhost:8120/feedback-mgmt/save-feedback'
    return this.http.post(feedback,obj);
  }

  public sendEventEmail(obj):Observable<any>{
    const reportEmailUrl='http://localhost:8120/feedback-mgmt/export-event'
    return this.http.post(reportEmailUrl,obj)
  }

  public downloadEvent():Observable<any>{
    const eventDownloadUrl='http://localhost:8120/feedback-mgmt/event-excel'
    return this.http.get(eventDownloadUrl);

  }
}

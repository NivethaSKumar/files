import { Component, OnInit } from '@angular/core';
import { ReportService } from '../report/report.service';
import { saveAs as importedSaveAs } from 'file-saver';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.scss']
})
export class EventComponent implements OnInit {
  public eventList:any=[];
  public emailId:string='';
  constructor(private reportService:ReportService) { }

  ngOnInit() {
    this.reportService.getEventDtls().subscribe(data=>{
      console.log('EventData',data);
      this.eventList=data; 
      console.log('list',this.eventList);
          })
      
  }
  public sendEventExcelEmail(){
    let requestBody={
        "emailId":this.emailId
        }
        console.log('req',requestBody);
  this.reportService.sendEventEmail(requestBody).subscribe(data=>{
    console.log('EmailId',data);
    this.emailId='';
  })
  
}
public downloadReportTemplate(){

  this.reportService.downloadEvent().subscribe(data => {
    const header = data.headers._headers.get('content-disposition')[0];
    const blob = new Blob([data._body], {
      type: 'application/excel'
    });
    importedSaveAs(blob, header.substr(header.indexOf('=') + 1));
    console.log('Value',data);
  });
}

}

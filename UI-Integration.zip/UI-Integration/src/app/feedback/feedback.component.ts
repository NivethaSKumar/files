import { Component, OnInit } from '@angular/core';
import { ReportService } from '../report/report.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.scss']
})
export class FeedbackComponent implements OnInit {
  public answer1 :string='';
  public answer2 :string='';
  public answer3 :string='';
  constructor(private reportService:ReportService) { }

  ngOnInit() {
    var unregistered: boolean = true;
    var notParticipated: boolean = false;
    var Participated: boolean = false;
  }
  public saveFeedbackInDb(){
    let requestBody={
      "answer1": this.answer1,
      "answer2":this.answer2,
      "answer3":this.answer3
      }
      console.log('req',requestBody);
      this.reportService.saveFeedback(requestBody).subscribe(data=>{
        console.log('Feedback',data);
        if(data.message=="Feedback successfully saved in database"){
          alert("Feedback successfully saved in database");
         }
         else {
       alert("Feedback is not saved successfully in database");
          }
        this.answer1='';
        this.answer2='';
        this.answer3='';
      })
  }

}

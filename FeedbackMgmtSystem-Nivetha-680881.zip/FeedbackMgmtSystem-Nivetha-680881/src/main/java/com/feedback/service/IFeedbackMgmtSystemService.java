package com.feedback.service;

import java.io.ByteArrayOutputStream;
import java.util.List;

import com.feedback.dto.EmailExcelDto;
import com.feedback.dto.EventDto;
import com.feedback.dto.FeedbackDto;
import com.feedback.dto.ReportDto;
import com.feedback.dto.UserDto;

public interface IFeedbackMgmtSystemService {

	String getLoginDetails(UserDto userDto);

	List<ReportDto> getReportDetails();

	List<EventDto> getEventDetails();

	String saveFeedback(FeedbackDto feedbackDto);

	ByteArrayOutputStream generateEventExcel();

	ByteArrayOutputStream generateReportExcel();

	String exportExcel(EmailExcelDto emailDto);

	String exportReport(EmailExcelDto emailDto);

}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './loginpage/loginpage.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EventComponent } from './event/event.component';
import { ReportComponent } from './report/report.component';
import { FeedbackComponent } from './feedback/feedback.component';


const routes: Routes = [
  {path: "", component: LoginPageComponent},
  {path:"dashboard", component: DashboardComponent},
  {path:"event",component: EventComponent},
  {path:"report",component: ReportComponent},
  {path:"feedback",component: FeedbackComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

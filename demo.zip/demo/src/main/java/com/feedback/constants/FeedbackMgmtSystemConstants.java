package com.feedback.constants;

public class FeedbackMgmtSystemConstants {

	public static final String EVENT_TEMPLATE_NAME = "Event.xls";
	public static final String REPORT_TEMPLATE_NAME = "Report.xls";

}

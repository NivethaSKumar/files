/*
 * package com.feedback.dto;
 * 
 * import java.io.ByteArrayOutputStream;
 * 
 * public class DownloadExcelDto { private ByteArrayOutputStream byteOs;
 * 
 * private String message ;
 * 
 * public ByteArrayOutputStream getByteOs() { return byteOs; }
 * 
 * public void setByteOs(ByteArrayOutputStream byteOs) { this.byteOs = byteOs; }
 * 
 * public String getMessage() { return message; }
 * 
 * public void setMessage(String message) { this.message = message; }
 * 
 * 
 * 
 * 
 * }
 */
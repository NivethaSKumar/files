import { Component, OnInit } from '@angular/core';
import { ReportService } from '../report/report.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.scss']
})
export class LoginPageComponent implements OnInit {

  constructor(private reportService:ReportService,private router:Router) { }
public email:string='';
public password:string='';
public errorMessage:string='';
ngOnInit() {
  }
public onClickloginDtls(){
  this.errorMessage='';
  //this.router.navigate(['dashboard']);
  let requestBody={
      "email":this.email,
      "pwd":this.password
      }
      console.log('req',requestBody);
this.reportService.loginDtls(requestBody).subscribe(data=>{
  console.log('login',data);
  // if(data){
  // this.displayError('Success',data.message)
  // }
  if(data.message=="Valid User.Login successful"){
    this.router.navigate(['dashboard']);
  }
  else{
this.errorMessage=data.message;
  }
  
})
}
}

/*
 * package com.feedback.dto;
 * 
 * import java.util.List;
 * 
 * public class CommonFeedbackDto {
 * 
 * private List<FeedbackDto> feedbackList;
 * 
 * public List<FeedbackDto> getFeedbackList() { return feedbackList; }
 * 
 * public void setFeedbackList(List<FeedbackDto> feedbackList) {
 * this.feedbackList = feedbackList; }
 * 
 * 
 * }
 */